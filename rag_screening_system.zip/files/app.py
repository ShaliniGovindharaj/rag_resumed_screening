"""
AI-Powered Resume Screener & ATS Optimization System
=====================================================
Technologies: Streamlit, PDFMiner, Sentence Transformers,
              FAISS, LangChain, Groq Llama 3.3 70B,
              Cosine Similarity, Plotly, ReportLab
"""

import streamlit as st
import os
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="ATS Resume Screener",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    /* ── BACKGROUND IMAGE on root ── */
    .stApp {
        background-image: url("https://images.unsplash.com/photo-1557804506-669a67965ba0?w=1600&auto=format&fit=crop");
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }

    /* ── SOLID WHITE MAIN CONTENT AREA ── */
    [data-testid="stMain"] {
        background: rgba(255, 255, 255, 0.95) !important;
        margin: 12px 12px 12px 0px;
        border-radius: 16px;
        padding: 0 !important;
    }
    [data-testid="stMainBlockContainer"] {
        background: transparent !important;
        padding: 2rem 2rem 2rem 2rem !important;
    }

    /* ── ALL TEXT BLACK ── */
    [data-testid="stMain"] p,
    [data-testid="stMain"] span,
    [data-testid="stMain"] label,
    [data-testid="stMain"] div,
    [data-testid="stMain"] h1,
    [data-testid="stMain"] h2,
    [data-testid="stMain"] h3,
    [data-testid="stMain"] h4,
    [data-testid="stMain"] small,
    [data-testid="stMain"] .stMarkdown {
        color: #1a1a1a !important;
    }

    /* ── SIDEBAR SOLID WHITE ── */
    section[data-testid="stSidebar"] {
        background: rgba(255, 255, 255, 0.98) !important;
    }
    section[data-testid="stSidebar"] * {
        color: #1a1a1a !important;
    }

    /* ── INPUT FIELDS WHITE BG, BLACK TEXT ── */
    .stTextInput input, .stTextArea textarea {
        background: #ffffff !important;
        color: #1a1a1a !important;
        border: 1.5px solid #c8d6e5 !important;
    }
    .stTextInput label, .stTextArea label {
        color: #1e3a5f !important;
        font-weight: 600 !important;
    }

    /* ── FILE UPLOADER ── */
    [data-testid="stFileUploader"] {
        background: #f0f4f8 !important;
        border-radius: 10px !important;
        border: 2px dashed #2d6a9f !important;
    }
    [data-testid="stFileUploader"] * {
        color: #1a1a1a !important;
    }

    /* ── ALERTS / INFO / WARNING BOXES ── */
    [data-testid="stAlert"] {
        background: #fff8e1 !important;
        border-radius: 8px !important;
    }
    [data-testid="stAlert"] * { color: #5a4000 !important; }

    /* ── HORIZONTAL RULE ── */
    hr { border-color: #dde4ed !important; }

    /* ── SIDEBAR WHITE bg ── */
    section[data-testid="stSidebar"] {
        background: rgba(255, 255, 255, 0.98) !important;
    }
    .main-header {
        background: linear-gradient(135deg, #1e3a5f 0%, #2d6a9f 50%, #1e3a5f 100%);
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 2rem;
        text-align: center;
        color: white;
        box-shadow: 0 8px 32px rgba(30,58,95,0.3);
    }
    .main-header h1 { font-size: 2.2rem; font-weight: 700; margin: 0; }
    .main-header p { font-size: 1rem; opacity: 0.85; margin-top: 0.5rem; }
    .score-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0,0,0,0.12);
        border-top: 4px solid #2d6a9f;
    }
    .score-card .score-value {
        font-size: 3rem;
        font-weight: 800;
        color: #1e3a5f;
        line-height: 1;
    }
    .score-card .score-label {
        font-size: 0.85rem;
        color: #666;
        margin-top: 0.3rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .section-card {
        background: #f8fafc;
        border-radius: 10px;
        padding: 1.2rem 1.5rem;
        margin-bottom: 1rem;
        border-left: 4px solid #2d6a9f;
    }
    .skill-tag-present {
        display: inline-block;
        background: #d4edda;
        color: #155724;
        border-radius: 20px;
        padding: 3px 12px;
        font-size: 0.82rem;
        margin: 3px;
        font-weight: 500;
    }
    .skill-tag-missing {
        display: inline-block;
        background: #f8d7da;
        color: #721c24;
        border-radius: 20px;
        padding: 3px 12px;
        font-size: 0.82rem;
        margin: 3px;
        font-weight: 500;
    }
    .status-excellent { color: #28a745; font-weight: 700; }
    .status-good { color: #17a2b8; font-weight: 700; }
    .status-average { color: #ffc107; font-weight: 700; }
    .status-poor { color: #dc3545; font-weight: 700; }
    .sidebar-info {
        background: #e8f0fe;
        border-radius: 8px;
        padding: 0.8rem;
        font-size: 0.85rem;
        margin-bottom: 0.5rem;
    }
    .tech-badge {
        display: inline-block;
        background: #1e3a5f;
        color: white;
        border-radius: 4px;
        padding: 2px 8px;
        font-size: 0.75rem;
        margin: 2px;
    }
    .email-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        border-left: 4px solid #28a745;
        margin-top: 1rem;
    }
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
</style>
""", unsafe_allow_html=True)

try:
    from ats_engine import (
        extract_text_from_pdf,
        build_faiss_vectorstore,
        calculate_ats_score,
        run_rag_evaluation,
        extract_skills,
        COMMON_TECH_SKILLS
    )
    from report_generator import generate_pdf_report
    import plotly.graph_objects as go
    LIBS_AVAILABLE = True
except ImportError as e:
    LIBS_AVAILABLE = False
    IMPORT_ERROR = str(e)


def send_email_report(sender_email, sender_password, recipient_email, 
                      pdf_bytes, resume_name, ats_score, status_label):
    """Send ATS report via email with PDF attachment."""
    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = recipient_email
        msg['Subject'] = f"📄 ATS Resume Analysis Report — {ats_score:.0f}% ({status_label})"

        body = f"""Hello,

Please find attached the AI-Powered ATS Resume Analysis Report.

📊 Summary:
• Resume: {resume_name}
• ATS Score: {ats_score:.1f}%
• Status: {status_label}

This report was generated using:
Groq Llama 3.3 70B · FAISS · LangChain · Sentence Transformers

Best regards,
AI Resume Screener
"""
        msg.attach(MIMEText(body, 'plain'))

        # Attach PDF
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(pdf_bytes)
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 
                        f'attachment; filename="ATS_Report_{resume_name.replace(".pdf","")}.pdf"')
        msg.attach(part)

        # Send via Gmail SMTP
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipient_email, msg.as_string())
        return True, "✅ Email sent successfully!"
    except smtplib.SMTPAuthenticationError:
        return False, "❌ Authentication failed. Use a Gmail App Password (not your regular password)."
    except Exception as e:
        return False, f"❌ Failed to send email: {str(e)}"


def get_ats_status(score):
    if score >= 80:
        return "Excellent Match", "status-excellent", "🟢"
    elif score >= 60:
        return "Good Match", "status-good", "🔵"
    elif score >= 40:
        return "Average Match", "status-average", "🟡"
    else:
        return "Poor Match", "status-poor", "🔴"


def render_gauge_chart(score, title="ATS Score"):
    color = "#28a745" if score >= 80 else "#17a2b8" if score >= 60 else "#ffc107" if score >= 40 else "#dc3545"
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=score,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title, 'font': {'size': 18, 'color': '#1e3a5f'}},
        delta={'reference': 70, 'increasing': {'color': "#28a745"}, 'decreasing': {'color': "#dc3545"}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#1e3a5f"},
            'bar': {'color': color},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "#e0e0e0",
            'steps': [
                {'range': [0, 40], 'color': '#ffe0e0'},
                {'range': [40, 60], 'color': '#fff3cd'},
                {'range': [60, 80], 'color': '#d1ecf1'},
                {'range': [80, 100], 'color': '#d4edda'}
            ],
            'threshold': {
                'line': {'color': "#1e3a5f", 'width': 4},
                'thickness': 0.75,
                'value': 70
            }
        }
    ))
    fig.update_layout(
        height=280,
        margin=dict(l=20, r=20, t=40, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return fig


def render_skills_bar_chart(present_skills, missing_skills):
    fig = go.Figure(go.Bar(
        x=['Present Skills', 'Missing Skills'],
        y=[len(present_skills), len(missing_skills)],
        marker_color=['#28a745', '#dc3545'],
        text=[len(present_skills), len(missing_skills)],
        textposition='auto',
        textfont={'size': 16, 'color': 'white'},
        width=0.4
    ))
    fig.update_layout(
        title={'text': 'Skill Coverage Analysis', 'font': {'size': 16, 'color': '#1e3a5f'}},
        yaxis_title="Count",
        height=300,
        margin=dict(l=20, r=20, t=50, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(248,250,252,1)',
        showlegend=False,
        yaxis=dict(gridcolor='#e0e0e0')
    )
    return fig


def render_radar_chart(scores_dict):
    categories = list(scores_dict.keys())
    values = list(scores_dict.values())
    values += values[:1]
    categories += categories[:1]
    fig = go.Figure(go.Scatterpolar(
        r=values,
        theta=categories,
        fill='toself',
        fillcolor='rgba(45, 106, 159, 0.2)',
        line=dict(color='#2d6a9f', width=2),
        marker=dict(color='#1e3a5f', size=8)
    ))
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 100], gridcolor='#e0e0e0'),
            angularaxis=dict(gridcolor='#e0e0e0')
        ),
        title={'text': 'Resume Profile Radar', 'font': {'size': 16, 'color': '#1e3a5f'}},
        height=350,
        margin=dict(l=40, r=40, t=60, b=40),
        paper_bgcolor='rgba(0,0,0,0)'
    )
    return fig


def render_skill_coverage_pie(present, missing):
    fig = go.Figure(go.Pie(
        labels=['Present', 'Missing'],
        values=[max(len(present), 1), max(len(missing), 1)],
        hole=0.5,
        marker=dict(colors=['#28a745', '#dc3545']),
        textfont=dict(size=14),
        hoverinfo='label+percent+value'
    ))
    fig.update_layout(
        title={'text': 'Skill Distribution', 'font': {'size': 16, 'color': '#1e3a5f'}},
        height=300,
        margin=dict(l=20, r=20, t=50, b=20),
        paper_bgcolor='rgba(0,0,0,0)'
    )
    return fig


# ── SIDEBAR ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ Configuration")
    groq_api_key = st.text_input(
        "🔑 Groq API Key",
        value=os.getenv("GROQ_API_KEY", ""),
        type="password",
        help="Get your free API key from console.groq.com"
    )
    st.markdown("---")
    st.markdown("### 📋 How It Works")
    steps = [
        ("1️⃣", "Upload Resume PDF"),
        ("2️⃣", "PDFMiner extracts text"),
        ("3️⃣", "Sentence Transformers embed"),
        ("4️⃣", "FAISS stores vectors"),
        ("5️⃣", "RAG retrieves context"),
        ("6️⃣", "Groq Llama 3.3 evaluates"),
        ("7️⃣", "ATS score + analysis"),
        ("8️⃣", "Download PDF report")
    ]
    for icon, step in steps:
        st.markdown(f"<div class='sidebar-info'>{icon} {step}</div>", unsafe_allow_html=True)
    st.markdown("---")
    st.markdown("### 🛠️ Tech Stack")
    techs = ["Streamlit", "PDFMiner.six", "Sentence Transformers",
             "FAISS", "LangChain", "Groq Llama 3.3 70B",
             "Cosine Similarity", "Plotly", "ReportLab"]
    tech_html = " ".join([f"<span class='tech-badge'>{t}</span>" for t in techs])
    st.markdown(tech_html, unsafe_allow_html=True)
    st.markdown("---")
    st.markdown("🟢 80–100 → Excellent")
    st.markdown("🔵 60–79 → Good")
    st.markdown("🟡 40–59 → Average")
    st.markdown("🔴 0–39 → Poor")


# ── MAIN ─────────────────────────────────────────────────────────────────
st.markdown("""
<div class='main-header'>
    <h1>📄 AI-Powered Resume Screener</h1>
    <p>ATS Optimization · Skill Gap Analysis · RAG-based AI Evaluation · Groq Llama 3.3 70B</p>
</div>
""", unsafe_allow_html=True)

if not LIBS_AVAILABLE:
    st.error(f"⚠️ Missing dependencies: {IMPORT_ERROR}")
    st.info("Run: `pip install -r requirements.txt`")
    st.stop()

if not groq_api_key:
    st.warning("⚠️ Please enter your Groq API key in the sidebar to use AI features.")

col1, col2 = st.columns([1, 1], gap="large")
with col1:
    st.markdown("### 📤 Upload Resume")
    uploaded_file = st.file_uploader(
        "Upload your resume (PDF format)",
        type=["pdf"],
        help="Supports PDF resumes up to 10MB"
    )
    if uploaded_file:
        st.success(f"✅ Uploaded: **{uploaded_file.name}** ({uploaded_file.size / 1024:.1f} KB)")

with col2:
    st.markdown("### 💼 Job Description")
    job_description = st.text_area(
        "Paste the job description here",
        height=200,
        placeholder="Paste the full job description here...\n\nExample:\nWe are looking for a Python Developer with experience in Django, FastAPI, PostgreSQL, Docker, and AWS...",
        help="The more detailed the JD, the better the ATS analysis"
    )
    jd_word_count = len(job_description.split()) if job_description else 0
    if jd_word_count > 0:
        st.caption(f"📝 Word count: {jd_word_count} words")

st.markdown("---")
analyze_btn = st.button(
    "🚀 Analyze Resume",
    type="primary",
    use_container_width=True,
    disabled=(not uploaded_file or not job_description.strip() or not groq_api_key)
)

if not uploaded_file:
    st.info("👆 Please upload a resume PDF to get started.")
elif not job_description.strip():
    st.info("👆 Please paste a job description to analyze against.")
elif not groq_api_key:
    st.info("👆 Please enter your Groq API key in the sidebar.")


# ── ANALYSIS PIPELINE ─────────────────────────────────────────────────────
if analyze_btn and uploaded_file and job_description.strip() and groq_api_key:

    os.environ["GROQ_API_KEY"] = groq_api_key
    progress_bar = st.progress(0)
    status_text = st.empty()

    try:
        status_text.markdown("**Step 1/6:** 📄 Extracting text from PDF using PDFMiner...")
        progress_bar.progress(10)
        resume_bytes = uploaded_file.read()
        resume_text = extract_text_from_pdf(resume_bytes)

        if not resume_text.strip():
            st.error("❌ Could not extract text from PDF. Please ensure it's not a scanned/image-only PDF.")
            st.stop()

        progress_bar.progress(20)
        time.sleep(0.3)

        status_text.markdown("**Step 2/6:** 🧠 Generating embeddings & building FAISS vector store...")
        progress_bar.progress(35)
        vectorstore, chunks = build_faiss_vectorstore(resume_text)
        progress_bar.progress(50)
        time.sleep(0.3)

        status_text.markdown("**Step 3/6:** 📊 Calculating ATS similarity score...")
        progress_bar.progress(60)
        ats_score, present_skills, missing_skills = calculate_ats_score(resume_text, job_description)
        progress_bar.progress(70)
        time.sleep(0.3)

        status_text.markdown("**Step 4/6:** 🤖 Running RAG pipeline with Groq Llama 3.3 70B...")
        progress_bar.progress(80)
        ai_feedback = run_rag_evaluation(vectorstore, job_description, groq_api_key)
        progress_bar.progress(90)
        time.sleep(0.3)

        status_text.markdown("**Step 5/6:** 🔍 Extracting skill details...")
        all_resume_skills = extract_skills(resume_text)
        progress_bar.progress(95)
        time.sleep(0.2)

        status_text.markdown("**Step 6/6:** ✅ Analysis complete!")
        progress_bar.progress(100)
        time.sleep(0.5)
        status_text.empty()
        progress_bar.empty()

        # ── RESULTS ──────────────────────────────────────────────────────
        st.markdown("---")
        st.markdown("## 📊 Analysis Results")

        status_label, status_class, status_icon = get_ats_status(ats_score)

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.markdown(f"""<div class='score-card'>
                <div class='score-value'>{ats_score:.0f}%</div>
                <div class='score-label'>ATS Score</div>
            </div>""", unsafe_allow_html=True)
        with m2:
            st.markdown(f"""<div class='score-card'>
                <div class='score-value'>{len(present_skills)}</div>
                <div class='score-label'>Skills Matched</div>
            </div>""", unsafe_allow_html=True)
        with m3:
            st.markdown(f"""<div class='score-card'>
                <div class='score-value'>{len(missing_skills)}</div>
                <div class='score-label'>Skills Missing</div>
            </div>""", unsafe_allow_html=True)
        with m4:
            st.markdown(f"""<div class='score-card'>
                <div class='score-value'>{len(chunks)}</div>
                <div class='score-label'>Resume Chunks</div>
            </div>""", unsafe_allow_html=True)

        st.markdown(f"<br><center><span class='{status_class}'>{status_icon} Status: {status_label}</span></center>", unsafe_allow_html=True)
        st.markdown("---")

        # ── CHARTS ───────────────────────────────────────────────────────
        st.markdown("### 📈 Visual Analysis")
        chart_c1, chart_c2 = st.columns(2)
        with chart_c1:
            st.plotly_chart(render_gauge_chart(ats_score, "ATS Match Score"), use_container_width=True)
        with chart_c2:
            st.plotly_chart(render_skills_bar_chart(present_skills, missing_skills), use_container_width=True)

        chart_c3, chart_c4 = st.columns(2)
        with chart_c3:
            radar_scores = {
                "Technical Skills": min(100, ats_score + 5),
                "Keywords": min(100, ats_score),
                "Experience": min(100, max(0, ats_score - 5 + len(present_skills))),
                "Education": min(100, ats_score + 10),
                "Soft Skills": min(100, ats_score + 8)
            }
            st.plotly_chart(render_radar_chart(radar_scores), use_container_width=True)
        with chart_c4:
            st.plotly_chart(render_skill_coverage_pie(present_skills, missing_skills), use_container_width=True)

        st.markdown("---")

        # ── SKILL GAP ────────────────────────────────────────────────────
        st.markdown("### 🎯 Skill Gap Analysis")
        sk1, sk2 = st.columns(2)
        with sk1:
            st.markdown("#### ✅ Present Skills")
            if present_skills:
                tags_html = " ".join([f"<span class='skill-tag-present'>{s}</span>" for s in sorted(present_skills)])
                st.markdown(tags_html, unsafe_allow_html=True)
            else:
                st.warning("No matching skills detected.")
        with sk2:
            st.markdown("#### ❌ Missing Skills")
            if missing_skills:
                tags_html = " ".join([f"<span class='skill-tag-missing'>{s}</span>" for s in sorted(missing_skills)])
                st.markdown(tags_html, unsafe_allow_html=True)
            else:
                st.success("🎉 All required skills are present!")

        st.markdown("---")

        # ── AI FEEDBACK ───────────────────────────────────────────────────
        st.markdown("### 🤖 AI Evaluation (RAG + Groq Llama 3.3 70B)")
        with st.expander("View Full AI Analysis", expanded=True):
            st.markdown(f"""<div class='section-card'>{ai_feedback}</div>""", unsafe_allow_html=True)

        st.markdown("---")

        # ── PREVIEW ───────────────────────────────────────────────────────
        with st.expander("📄 Extracted Resume Text (PDFMiner Output)", expanded=False):
            st.text_area("Resume Text", resume_text[:3000] + ("..." if len(resume_text) > 3000 else ""), height=300)
            st.caption(f"Total characters extracted: {len(resume_text)}")

        with st.expander(f"🗄️ FAISS Vector Store Chunks ({len(chunks)} chunks)", expanded=False):
            for i, chunk in enumerate(chunks[:5]):
                st.markdown(f"**Chunk {i+1}:**")
                st.text(chunk[:200] + "..." if len(chunk) > 200 else chunk)
            if len(chunks) > 5:
                st.caption(f"... and {len(chunks)-5} more chunks stored in FAISS")

        st.markdown("---")

        # ── PDF REPORT ────────────────────────────────────────────────────
        st.markdown("### 📥 Download Report")
        with st.spinner("Generating PDF report with ReportLab..."):
            pdf_bytes = generate_pdf_report(
                resume_filename=uploaded_file.name,
                ats_score=ats_score,
                present_skills=present_skills,
                missing_skills=missing_skills,
                ai_feedback=ai_feedback,
                job_description=job_description,
                resume_text=resume_text,
                status_label=status_label,
                num_chunks=len(chunks)
            )

        st.download_button(
            label="⬇️ Download ATS Report (PDF)",
            data=pdf_bytes,
            file_name=f"ATS_Report_{uploaded_file.name.replace('.pdf','')}_{int(time.time())}.pdf",
            mime="application/pdf",
            use_container_width=True,
            type="primary"
        )
        st.caption("📄 Report generated using ReportLab")

        # ── EMAIL REPORT ──────────────────────────────────────────────────
        st.markdown("---")
        st.markdown("### 📧 Send Report via Email")

        # Load credentials — hardcoded
        env_sender   = "shalinianu0303@gmail.com"
        env_password = "fjnk ncnf nyvv gqsf"
        env_receiver = "717823i153@kce.ac.in"

        st.markdown(f"""
        <div style='background:#f0f7ff; border-radius:12px; padding:1.2rem 1.5rem;
                    border-left:5px solid #2d6a9f; margin-bottom:1rem;'>
            <b style='color:#1e3a5f; font-size:1rem;'>📬 Email ATS Report as PDF</b><br><br>
            <span style='color:#333;'>📤 <b>From:</b> {env_sender or "Not set in .env"}</span><br>
            <span style='color:#333;'>📨 <b>To:</b> {env_receiver or "Not set in .env"}</span>
        </div>
        """, unsafe_allow_html=True)

        send_btn = st.button(
            "📤 Send Report to Email",
            type="primary",
            use_container_width=True,
            disabled=(not env_sender or not env_password or not env_receiver)
        )

        if not env_sender or not env_password or not env_receiver:
            st.warning("⚠️ Add SENDER_EMAIL, SENDER_PASSWORD, RECEIVER_EMAIL in your `.env` file.")

        if send_btn and env_sender and env_password and env_receiver:
            with st.spinner("📤 Sending email... please wait..."):
                success, message = send_email_report(
                    sender_email=env_sender,
                    sender_password=env_password,
                    recipient_email=env_receiver,
                    pdf_bytes=pdf_bytes,
                    resume_name=uploaded_file.name,
                    ats_score=ats_score,
                    status_label=status_label
                )
            if success:
                st.success(f"✅ Report sent successfully to **{env_receiver}**!")
                st.balloons()
            else:
                st.error(message)
                st.markdown("""
                **Troubleshooting:**
                - ✅ 2-Step Verification ON பண்ணு Gmail-ல்
                - ✅ SENDER_PASSWORD = 16-char App Password (Gmail login password இல்லை)
                - 🔗 [Get App Password](https://myaccount.google.com/apppasswords)
                """)

    except Exception as e:
        progress_bar.empty()
        status_text.empty()
        st.error(f"❌ Analysis failed: {str(e)}")
        with st.expander("🔍 Error Details"):
            import traceback
            st.code(traceback.format_exc())

st.markdown("---")
st.markdown("""
<center><small>
Built with ❤️ using
<b>Streamlit</b> · <b>PDFMiner.six</b> · <b>Sentence Transformers</b> · <b>FAISS</b> ·
<b>LangChain</b> · <b>Groq Llama 3.3 70B</b> · <b>Cosine Similarity</b> · <b>Plotly</b> · <b>ReportLab</b>
</small></center>
""", unsafe_allow_html=True)
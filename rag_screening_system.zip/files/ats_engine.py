"""
ats_engine.py
=============
Core processing engine using:
- PDFMiner.six       → PDF text extraction
- Sentence Transformers → Embeddings generation
- FAISS              → Vector database
- LangChain          → RAG pipeline
- Groq Llama 3.3 70B → LLM evaluation
- Cosine Similarity  → ATS scoring
"""

import io
import re
import numpy as np
from typing import Tuple, List, Set

# ── PDFMiner ──────────────────────────────────────────────────────────────
from pdfminer.high_level import extract_text as pdfminer_extract_text
from pdfminer.layout import LAParams

# ── Sentence Transformers ─────────────────────────────────────────────────
from sentence_transformers import SentenceTransformer

# ── FAISS ─────────────────────────────────────────────────────────────────
import faiss

# ── LangChain (ALL FIXED IMPORTS) ─────────────────────────────────────────
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS as LangChainFAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

# ── Cosine Similarity ─────────────────────────────────────────────────────
from sklearn.metrics.pairwise import cosine_similarity


# ─────────────────────────────────────────────────────────────────────────
# COMMON TECH SKILLS DATABASE
# ─────────────────────────────────────────────────────────────────────────
COMMON_TECH_SKILLS = {
    "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust",
    "kotlin", "swift", "php", "ruby", "scala", "r", "matlab", "perl", "bash",
    "shell scripting", "sql", "html", "css",
    "django", "flask", "fastapi", "spring boot", "spring", "express", "react",
    "angular", "vue", "nextjs", "nestjs", "tensorflow", "pytorch", "keras",
    "scikit-learn", "pandas", "numpy", "scipy", "matplotlib", "seaborn",
    "hugging face", "langchain", "streamlit",
    "postgresql", "mysql", "mongodb", "redis", "sqlite", "cassandra",
    "elasticsearch", "neo4j", "dynamodb", "oracle", "mssql", "faiss",
    "pinecone", "weaviate", "chroma",
    "aws", "azure", "gcp", "google cloud", "docker", "kubernetes", "terraform",
    "ansible", "jenkins", "github actions", "gitlab ci", "circleci",
    "helm", "prometheus", "grafana", "elk stack",
    "machine learning", "deep learning", "nlp", "computer vision",
    "natural language processing", "transformers", "bert", "gpt",
    "llm", "rag", "vector database", "embedding", "fine-tuning",
    "data science", "data engineering", "data analysis", "big data",
    "spark", "hadoop", "airflow", "dbt", "kafka",
    "git", "github", "gitlab", "bitbucket", "jira", "agile", "scrum",
    "rest api", "graphql", "microservices", "ci/cd", "tdd", "solid",
    "design patterns", "object-oriented", "functional programming",
    "cybersecurity", "penetration testing", "oauth", "jwt", "ssl/tls",
    "cryptography", "network security",
    "android", "ios", "react native", "flutter",
}


# ─────────────────────────────────────────────────────────────────────────
# 1. PDF TEXT EXTRACTION — PDFMiner.six
# ─────────────────────────────────────────────────────────────────────────
def extract_text_from_pdf(pdf_bytes: bytes) -> str:
    laparams = LAParams(
        line_margin=0.5,
        char_margin=2.0,
        word_margin=0.1,
        boxes_flow=0.5,
        detect_vertical=False
    )
    pdf_file = io.BytesIO(pdf_bytes)
    text = pdfminer_extract_text(pdf_file, laparams=laparams)
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r' {2,}', ' ', text)
    text = text.strip()
    return text


# ─────────────────────────────────────────────────────────────────────────
# 2. FAISS VECTOR STORE — LangChain + Sentence Transformers + FAISS
# ─────────────────────────────────────────────────────────────────────────
def build_faiss_vectorstore(resume_text: str):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100,
        length_function=len,
        separators=["\n\n", "\n", ".", " ", ""]
    )
    chunks = text_splitter.split_text(resume_text)
    chunks = [c.strip() for c in chunks if len(c.strip()) > 20]

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True}
    )

    vectorstore = LangChainFAISS.from_texts(chunks, embeddings)
    return vectorstore, chunks


# ─────────────────────────────────────────────────────────────────────────
# 3. ATS SCORE — Cosine Similarity
# ─────────────────────────────────────────────────────────────────────────
def calculate_ats_score(resume_text: str, job_description: str) -> Tuple[float, Set[str], Set[str]]:
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    resume_embedding = model.encode([resume_text])
    jd_embedding = model.encode([job_description])
    cos_sim = cosine_similarity(resume_embedding, jd_embedding)[0][0]
    cosine_score = float(np.clip(cos_sim * 100, 0, 100))

    resume_lower = resume_text.lower()
    jd_lower = job_description.lower()

    jd_skills = set()
    for skill in COMMON_TECH_SKILLS:
        if skill.lower() in jd_lower:
            jd_skills.add(skill.lower())

    present_skills = set()
    missing_skills = set()
    for skill in jd_skills:
        if skill in resume_lower:
            present_skills.add(skill)
        else:
            missing_skills.add(skill)

    jd_words = set(re.findall(r'\b[a-z]{3,}\b', jd_lower))
    resume_words = set(re.findall(r'\b[a-z]{3,}\b', resume_lower))
    stop_words = {'the', 'and', 'for', 'are', 'with', 'this', 'that',
                  'have', 'from', 'will', 'you', 'your', 'our', 'their',
                  'was', 'been', 'has', 'not', 'but', 'they', 'we', 'can'}
    jd_words -= stop_words
    resume_words -= stop_words

    keyword_overlap = len(jd_words & resume_words) / max(len(jd_words), 1)
    keyword_score = float(np.clip(keyword_overlap * 100, 0, 100))

    if jd_skills:
        skill_score = (len(present_skills) / len(jd_skills)) * 100
    else:
        skill_score = cosine_score

    final_score = (cosine_score * 0.40) + (keyword_score * 0.35) + (skill_score * 0.25)
    final_score = float(np.clip(final_score, 0, 100))

    return final_score, present_skills, missing_skills


# ─────────────────────────────────────────────────────────────────────────
# 4. RAG EVALUATION — LangChain + FAISS + Groq Llama 3.3 70B
# ─────────────────────────────────────────────────────────────────────────
def run_rag_evaluation(vectorstore, job_description: str, groq_api_key: str) -> str:
    import os
    os.environ["GROQ_API_KEY"] = groq_api_key

    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": 4}
    )

    llm = ChatGroq(
        model="llama-3.3-70b-versatile",
        temperature=0.3,
        max_tokens=1500,
        api_key=groq_api_key
    )

    prompt_template = PromptTemplate(
        input_variables=["context", "question"],
        template="""You are an expert ATS (Applicant Tracking System) and HR specialist.
Based on the resume context provided, evaluate the candidate for the given job description.

Resume Context (retrieved from FAISS vector store):
{context}

Job Description & Evaluation Request:
{question}

Please provide a structured evaluation with:

## 🎯 Overall Assessment
[2-3 sentences summarizing candidate fit]

## 💪 Key Strengths
[3-5 bullet points of strong matches]

## ⚠️ Areas for Improvement
[3-5 bullet points of gaps or weaknesses]

## 📈 Recommendations
[3-5 actionable suggestions to improve resume/profile]

## 🔑 Keyword Optimization Tips
[Specific keywords or phrases to add to the resume]

Be specific, actionable, and professional."""
    )

    # ── RAG Chain (new LangChain style — no langchain.chains needed) ──────
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    rag_chain = (
        {
            "context": retriever | format_docs,
            "question": RunnablePassthrough()
        }
        | prompt_template
        | llm
        | StrOutputParser()
    )

    query = f"""Evaluate this resume against the following job description and provide detailed feedback:

Job Description:
{job_description[:1500]}

Analyze: technical skills match, experience relevance, keyword optimization,
missing qualifications, and provide specific improvement recommendations."""

    result = rag_chain.invoke(query)
    return result


# ─────────────────────────────────────────────────────────────────────────
# 5. SKILL EXTRACTION
# ─────────────────────────────────────────────────────────────────────────
def extract_skills(text: str) -> Set[str]:
    text_lower = text.lower()
    found_skills = set()
    for skill in COMMON_TECH_SKILLS:
        if skill.lower() in text_lower:
            found_skills.add(skill)
    return found_skills


# ─────────────────────────────────────────────────────────────────────────
# 6. RAW FAISS INDEX
# ─────────────────────────────────────────────────────────────────────────
def build_raw_faiss_index(texts: List[str]) -> Tuple:
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    embeddings = model.encode(texts, convert_to_numpy=True)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    embeddings = embeddings / (norms + 1e-10)
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatIP(dimension)
    index.add(embeddings.astype('float32'))
    return index, embeddings, model
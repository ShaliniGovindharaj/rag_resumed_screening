"""
report_generator.py
====================
PDF report generation using ReportLab.
"""

import io
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.colors import HexColor, white
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak
)
from reportlab.platypus.flowables import Flowable

PRIMARY   = HexColor("#1e3a5f")
SECONDARY = HexColor("#2d6a9f")
SUCCESS   = HexColor("#28a745")
WARNING   = HexColor("#ffc107")
DANGER    = HexColor("#dc3545")
INFO      = HexColor("#17a2b8")
LIGHT_BG  = HexColor("#f8fafc")
LIGHT_GREY= HexColor("#e9ecef")
DARK_TEXT = HexColor("#212529")
MUTED_TEXT= HexColor("#6c757d")
WHITE     = white


def get_score_color(score):
    if score >= 80: return SUCCESS
    if score >= 60: return INFO
    if score >= 40: return WARNING
    return DANGER


def get_score_label(score):
    if score >= 80: return "Excellent Match"
    if score >= 60: return "Good Match"
    if score >= 40: return "Average Match"
    return "Poor Match"


def generate_pdf_report(
    resume_filename, ats_score, present_skills, missing_skills,
    ai_feedback, job_description, resume_text, status_label, num_chunks
) -> bytes:

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2.5*cm, bottomMargin=2*cm,
        title="ATS Resume Analysis Report",
        author="AI Resume Screener"
    )

    styles = getSampleStyleSheet()
    score_color = get_score_color(ats_score)

    style_title = ParagraphStyle('RT', parent=styles['Heading1'],
        fontSize=22, textColor=WHITE, spaceAfter=4,
        alignment=TA_CENTER, fontName='Helvetica-Bold')
    style_subtitle = ParagraphStyle('RS', parent=styles['Normal'],
        fontSize=10, textColor=HexColor("#d0e8ff"),
        alignment=TA_CENTER, fontName='Helvetica')
    style_section = ParagraphStyle('SH', parent=styles['Heading2'],
        fontSize=13, textColor=PRIMARY,
        spaceBefore=12, spaceAfter=6, fontName='Helvetica-Bold')
    style_body = ParagraphStyle('BT', parent=styles['Normal'],
        fontSize=10, textColor=DARK_TEXT,
        spaceAfter=4, fontName='Helvetica', leading=15)
    style_bullet = ParagraphStyle('BU', parent=styles['Normal'],
        fontSize=9.5, textColor=DARK_TEXT,
        leftIndent=16, spaceAfter=3, fontName='Helvetica', leading=14)

    story = []

    # ── HEADER ───────────────────────────────────────────────────────────
    header_data = [[
        Paragraph("📄 ATS Resume Analysis Report", style_title),
        Paragraph(
            f"Generated: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}<br/>"
            f"Powered by Groq Llama 3.3 70B · FAISS · LangChain · Sentence Transformers",
            style_subtitle
        )
    ]]
    header_table = Table(header_data, colWidths=[17*cm])
    header_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), PRIMARY),
        ('TOPPADDING', (0,0), (-1,-1), 18),
        ('BOTTOMPADDING', (0,0), (-1,-1), 18),
        ('LEFTPADDING', (0,0), (-1,-1), 20),
        ('RIGHTPADDING', (0,0), (-1,-1), 20),
        ('SPAN', (0,0), (-1,-1)),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(header_table)
    story.append(Spacer(1, 0.5*cm))

    # ── SCORE CARDS ───────────────────────────────────────────────────────
    story.append(Paragraph("📊 Score Overview", style_section))
    story.append(HRFlowable(width="100%", thickness=1, color=LIGHT_GREY, spaceAfter=8))

    def make_card(value, label, border_color):
        inner = Table([
            [Paragraph(f"<font size='20'><b>{value}</b></font>",
                ParagraphStyle('cv', alignment=TA_CENTER, fontName='Helvetica-Bold'))],
            [Paragraph(f"<font size='9' color='#6c757d'>{label}</font>",
                ParagraphStyle('cl', alignment=TA_CENTER, fontName='Helvetica'))]
        ], colWidths=[3.8*cm])
        inner.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), LIGHT_BG),
            ('BOX', (0,0), (-1,-1), 2, border_color),
            ('TOPPADDING', (0,0), (-1,-1), 10),
            ('BOTTOMPADDING', (0,0), (-1,-1), 10),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ]))
        return inner

    cards_row = [[
        make_card(f"{ats_score:.0f}%", "ATS Score", score_color),
        make_card(str(len(present_skills)), "Skills Matched", SUCCESS),
        make_card(str(len(missing_skills)), "Skills Missing", DANGER),
        make_card(str(num_chunks), "FAISS Chunks", SECONDARY),
    ]]
    cards_table = Table(cards_row, colWidths=[4.1*cm]*4, hAlign='CENTER')
    cards_table.setStyle(TableStyle([
        ('LEFTPADDING', (0,0), (-1,-1), 3),
        ('RIGHTPADDING', (0,0), (-1,-1), 3),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(cards_table)
    story.append(Spacer(1, 0.3*cm))

    emoji = "🟢" if ats_score >= 80 else "🔵" if ats_score >= 60 else "🟡" if ats_score >= 40 else "🔴"
    story.append(Paragraph(f"{emoji} Verdict: {status_label}",
        ParagraphStyle('st', alignment=TA_CENTER, fontSize=12,
        fontName='Helvetica-Bold', textColor=score_color, spaceAfter=8)))

    # ── ANALYSIS DETAILS ──────────────────────────────────────────────────
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph("📋 Analysis Details", style_section))
    story.append(HRFlowable(width="100%", thickness=1, color=LIGHT_GREY, spaceAfter=8))

    info_data = [
        ["Resume File", resume_filename],
        ["Analysis Date", datetime.now().strftime("%B %d, %Y %I:%M %p")],
        ["ATS Score", f"{ats_score:.1f}% ({status_label})"],
        ["Matched Skills", f"{len(present_skills)} skills detected"],
        ["Missing Skills", f"{len(missing_skills)} skills to add"],
        ["FAISS Chunks", f"{num_chunks} chunks in vector store"],
        ["LLM Used", "Groq Llama 3.3 70B Versatile"],
        ["Embedding Model", "Sentence Transformers (all-MiniLM-L6-v2)"],
    ]
    info_table = Table(info_data, colWidths=[5*cm, 12*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
        ('FONTNAME', (1,0), (1,-1), 'Helvetica'),
        ('FONTSIZE', (0,0), (-1,-1), 9.5),
        ('TEXTCOLOR', (0,0), (0,-1), PRIMARY),
        ('ROWBACKGROUNDS', (0,0), (-1,-1), [WHITE, LIGHT_BG]),
        ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(info_table)

    # ── SKILL GAP ────────────────────────────────────────────────────────
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph("🎯 Skill Gap Analysis", style_section))
    story.append(HRFlowable(width="100%", thickness=1, color=LIGHT_GREY, spaceAfter=8))

    present_list = sorted(present_skills)
    missing_list = sorted(missing_skills)

    def skill_para(skills, dot_color):
        if not skills:
            return Paragraph("None detected.", style_body)
        lines = "<br/>".join([
            f"<font color='{dot_color}'>■</font> {sk}" for sk in skills
        ])
        return Paragraph(lines, ParagraphStyle('sk', fontName='Helvetica',
            fontSize=9, leading=14, textColor=DARK_TEXT))

    skill_data = [[
        Paragraph("✅ Present Skills", ParagraphStyle('sh', fontName='Helvetica-Bold',
            fontSize=11, textColor=SUCCESS, spaceAfter=6)),
        Paragraph("❌ Missing Skills", ParagraphStyle('sh', fontName='Helvetica-Bold',
            fontSize=11, textColor=DANGER, spaceAfter=6))
    ], [
        skill_para(present_list, '#155724'),
        skill_para(missing_list, '#721c24')
    ]]
    skill_table = Table(skill_data, colWidths=[8.3*cm, 8.3*cm])
    skill_table.setStyle(TableStyle([
        ('BACKGROUND', (0,1), (0,-1), HexColor("#f0fff4")),
        ('BACKGROUND', (1,1), (1,-1), HexColor("#fff5f5")),
        ('BOX', (0,1), (0,-1), 1, SUCCESS),
        ('BOX', (1,1), (1,-1), 1, DANGER),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ]))
    story.append(skill_table)

    # ── AI EVALUATION ─────────────────────────────────────────────────────
    story.append(PageBreak())
    story.append(Paragraph("🤖 AI Evaluation Report", style_section))
    story.append(Paragraph(
        "Generated using RAG Pipeline: FAISS Retriever + LangChain + Groq Llama 3.3 70B",
        ParagraphStyle('ai_sub', fontName='Helvetica', fontSize=9,
            textColor=MUTED_TEXT, spaceAfter=8)))
    story.append(HRFlowable(width="100%", thickness=1, color=LIGHT_GREY, spaceAfter=8))

    for line in ai_feedback.split('\n'):
        line = line.strip()
        if not line:
            story.append(Spacer(1, 0.15*cm))
        elif line.startswith('## ') or line.startswith('# '):
            story.append(Paragraph(line.replace('## ','').replace('# ',''), style_section))
        elif line.startswith(('- ', '• ', '* ')):
            story.append(Paragraph(f"• {line[2:]}", style_bullet))
        else:
            cleaned = line.replace('**','').replace('*','').replace('`','')
            story.append(Paragraph(cleaned, style_body))

    # ── TECHNOLOGY PIPELINE ───────────────────────────────────────────────
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph("🛠️ Technology Pipeline", style_section))
    story.append(HRFlowable(width="100%", thickness=1, color=LIGHT_GREY, spaceAfter=8))

    pipeline_data = [
        ["Step", "Technology", "Purpose"],
        ["1", "PDFMiner.six", "PDF text extraction with layout analysis"],
        ["2", "LangChain TextSplitter", "Recursive text chunking (500 chars, 100 overlap)"],
        ["3", "Sentence Transformers", "Semantic embeddings (all-MiniLM-L6-v2)"],
        ["4", "FAISS VectorStore", "Store & retrieve embeddings via similarity search"],
        ["5", "Cosine Similarity", "ATS score (weighted: 40%+35%+25%)"],
        ["6", "LangChain RAG Chain", "RetrievalQA with FAISS retriever (k=4)"],
        ["7", "Groq Llama 3.3 70B", "AI evaluation with structured feedback"],
        ["8", "Plotly", "Interactive charts (gauge, radar, bar, pie)"],
        ["9", "ReportLab", "Professional PDF report generation"],
        ["10", "python-dotenv", "Secure environment variable management"],
    ]
    pipeline_table = Table(pipeline_data, colWidths=[1*cm, 5.5*cm, 10.1*cm])
    pipeline_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), PRIMARY),
        ('TEXTCOLOR', (0,0), (-1,0), WHITE),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), 9),
        ('FONTNAME', (0,1), (0,-1), 'Helvetica-Bold'),
        ('FONTNAME', (1,1), (-1,-1), 'Helvetica'),
        ('TEXTCOLOR', (1,1), (1,-1), SECONDARY),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [WHITE, LIGHT_BG]),
        ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('ALIGN', (0,0), (0,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(pipeline_table)

    # ── FOOTER ────────────────────────────────────────────────────────────
    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=LIGHT_GREY))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        "AI-Powered Resume Screener | Streamlit · PDFMiner · Sentence Transformers · "
        "FAISS · LangChain · Groq Llama 3.3 70B · Plotly · ReportLab",
        ParagraphStyle('ft', alignment=TA_CENTER, fontSize=8,
            textColor=MUTED_TEXT, fontName='Helvetica')
    ))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
